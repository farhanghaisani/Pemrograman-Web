<?php

namespace app\Config;

class DatabaseConfig
{
    //Setting database
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "praktikum4";
    public $port = "3306";
}
?>